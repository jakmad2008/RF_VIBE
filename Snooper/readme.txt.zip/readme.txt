if crashed the game try to download and run the support file from this:

Link: https://allinoneruntimes.org/files/aio-runtimes_v2.5.0.exe
(this file is not dangerous, just to complete the runtime needs on your PC)

- follow the instruction install
- if you have finished installing, play the game. thank you!